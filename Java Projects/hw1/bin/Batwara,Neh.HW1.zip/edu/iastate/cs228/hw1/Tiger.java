package edu.iastate.cs228.hw1;

public class Tiger extends Animal {

	public Tiger(String name, int health) {
		super(name, health);
		
	}

	@Override
	public void interact(Animal objAnimal) {
		if (objAnimal instanceof Sheep){
			health = health + objAnimal.getHealth();
			objAnimal.setHealth(0);
		}
		else if (objAnimal instanceof Bengal){
			if (objAnimal.getHealth() > this.health){
				this.health = (int) (this.health * 0.9);
			}
			else if(objAnimal.getHealth() < this.health){
				objAnimal.setHealth((int)(objAnimal.getHealth() * 0.9));
			}
			else {
				
			}
		}
		else if(objAnimal instanceof Tiger){
			growl();
		}
		else {
			
		}
		
	}
	public void growl(){
		System.out.println("Prrr.");
	}

}
