/**
 * 
 */
package edu.iastate.cs228.hw1;

/**
 * @author Neh Batwara
 *
 */
public class Bengal extends Tiger {

	public Bengal(String name, int health) {
		super(name, health);
		
	}

	/* (non-Javadoc)
	 * @see edu.iastate.cs228.hw1.Animal#interact(edu.iastate.cs228.hw1.Animal)
	 */
	@Override
	public void interact(Animal objAnimal) {
		if (objAnimal instanceof Sheep){
			health = health + objAnimal.getHealth();
			objAnimal.setHealth(0);
		}
		else if (objAnimal instanceof Tiger){
			if (objAnimal.getHealth() > this.health){
				this.health = (int) (this.health * 0.9);
			}
			else if(objAnimal.getHealth() < this.health){
				objAnimal.setHealth((int)(objAnimal.getHealth() * 0.9));
			}
			else {
				
			}
		}
		else if(objAnimal instanceof Bengal){
			growl();
		}
		else{
			
		}

	}
	@Override 
	public void growl(){
		System.out.println("RAWR");
		health++;
	}

}
