/**
 * 
 */
package edu.iastate.cs228.hw1;

/**
 * @author Neh Batwara
 * 
 */
public abstract class Animal implements Comparable<Animal> {
	protected String name;
	protected int health;

	public String getName() {
		return name;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj instanceof Animal){
			Animal objAnimal = (Animal) obj;
			if ( this.getName().equals(objAnimal.getName())
					&& this.getHealth() == objAnimal.getHealth()){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	@Override
	public int compareTo(Animal objAnimal) {
		// TODO Auto-generated method stub
		if(this.getHealth() > objAnimal.getHealth()){
			return 1;
		}
		else if( this.getHealth() < objAnimal.getHealth()){
			return -1;
		}
		else {
			return 0;
		}
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	@Override
	public String toString() {
		return name + " , " + health;
	}
	
	public abstract void interact( Animal a);
		
	public Animal( String name,  int health ){
		this.name = name;
		this.health = health;
		
	}

}
