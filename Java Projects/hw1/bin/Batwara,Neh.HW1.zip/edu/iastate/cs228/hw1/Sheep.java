/**
 * 
 */
package edu.iastate.cs228.hw1;

/**
 * @author Neh Batwara
 *
 */
public class Sheep extends Animal {

	public Sheep(String name, int health) {
		super(name, health);
		
	}

	/* (non-Javadoc)
	 * @see edu.iastate.cs228.hw1.Animal#interact(edu.iastate.cs228.hw1.Animal)
	 */
	@Override
	public void interact(Animal a) {
		System.out.println("Baaaaah");
		
	}

}
