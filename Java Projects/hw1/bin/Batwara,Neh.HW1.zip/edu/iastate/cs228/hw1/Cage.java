/**
 * 
 */
package edu.iastate.cs228.hw1;

import java.util.Arrays;

/**
 * @author Neh Batwara
 * 
 */
public class Cage<T> {
	T[] arrayOfAnimals = null;
	private int numAnimals = 0;

	public Cage(int numberOfAnimals) throws CageException {
		if (numberOfAnimals <= 0) {
			throw new CageException(
					"number of animals must be greater than zero");
		} else {
			arrayOfAnimals = (T[]) new Animal[numberOfAnimals];
		}
	}

	public Animal[] getOccupants() {
		return (Animal[]) arrayOfAnimals;
	}

	public int getCapacity() {
		return arrayOfAnimals.length;
	}

	public void add(T animal) throws CageException {
		// if (availableCell == getCapacity()) {
		// throw new CageException(" Capacity exceeded. Limit = "
		// + getCapacity());
		// } else {
		//
		// }
		// String newAnimalName = ((Animal) animal).getName();
		// for (int i = 0; i < availableCell; i++) {

		String newAnimalName = ((Animal) animal).getName();
		int availableCell = -1;
		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals[i] == null) {
				availableCell = i;
				continue;
			} else {
				String existingAnimalName = ((Animal) arrayOfAnimals[i])
						.getName();

				if (existingAnimalName.equals(newAnimalName)) {
					throw new CageException("Animal with name exists");
				} else {

				}
			}
		}
		if (availableCell == -1) {
			throw new CageException(" Capcity exceeded ");
		} else {
			arrayOfAnimals[availableCell] = animal;
		}
	}

	public String[] listAnimalsSorted() {
		int totalNoOfAnimals = 0;
		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals[i] != null) {
				totalNoOfAnimals++;
			} else {

			}
		}
		Animal[] fullArrayOfAnimals = new Animal[totalNoOfAnimals];
		int animalIndex= 0;
		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals[i] != null) {
				fullArrayOfAnimals[animalIndex++] = (Animal) arrayOfAnimals[i];
			} else {
				//do nothing here.
			}
		}
		Arrays.sort(fullArrayOfAnimals);
		String[] sortedAnimals = new String[fullArrayOfAnimals.length];
		for (int i = 0; i < fullArrayOfAnimals.length; i++) {
			sortedAnimals[i] = fullArrayOfAnimals[i].toString();
		}
		return sortedAnimals;
	}

	public void remove(String animalName) throws CageException {
		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals != null) {
				String existingAnimalName = ((Animal) arrayOfAnimals[i])
						.getName();

				if (existingAnimalName.equals(animalName)) {
					arrayOfAnimals[i] = null;
					return;
				}

			}

		}
		throw new CageException("Animal does not exist");
	}

	public void simulate() {
		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals[i] == null) {
				continue;
			}
			Animal interactingAnimal = (Animal) arrayOfAnimals[i];
			for (int j = 0; j < getCapacity(); j++) {
				if (arrayOfAnimals[j] == null || i == j) {
					continue;
				} else {
					// do nothing here. go ahead
				}
				interactingAnimal.interact((Animal) arrayOfAnimals[j]);
			}
		}

		for (int i = 0; i < getCapacity(); i++) {
			if (arrayOfAnimals[i] == null) {
				continue;
			}
			Animal objAnimal = (Animal) arrayOfAnimals[i];
			if (objAnimal.getHealth() <= 0) {
				try {
					remove(objAnimal.getName());
				} catch (CageException e) {
					// code should never reach here.
					// System.out.println("WARNING : EXCEPTION OCCURED : "
					// +e.getMessage());
				}
			}
		}

	}

}
