/**
 * 
 */
package edu.iastate.cs228.hw1;

/**
 * @author Neh Batwara
 *
 */
public class CageException extends Exception {

public CageException(String message){
	super(message);
}
	
}
